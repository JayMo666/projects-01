package com.example.flutter_duuchin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
